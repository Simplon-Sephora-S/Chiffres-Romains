/*jslint browser: true*/
/*global $, jQuery, alert*/
$(function () {
  // Styles des cartes
  // Verso (le même pour toute les cartes)
  var verso = document.getElementsByClassName('f1_card');
  verso = $('.f1_card').css('background-color', "DarkSeaGreen");

  var carteConteneur = document.getElementsByClassName('f1_container');
  ///////////////////////////////////
  ///////////////////////////////////
  /////////////////////////////////// Creer une boucle qui reproduit ce bout de code 4 fois en tout
  ///////////////////////////////////
  ///////////////////////////////////

  
  /////////////////////////////////// Carte 1   ///////////////////////////////////

  // Chiffre aléatoire qui détermine l'affichage de la couleur
  var chiffreAleatoire = Math.floor(Math.random() * 5);
  console.log(chiffreAleatoire);

  // Distribution aléatoire des rectos
  function distributionVerso(){
    switch (chiffreAleatoire) {
      case 0:
      $('.face.back').css('background-color', "Lightgreen");
      break;
      case 1:
      $('.face.back').css('background-color', "Coral");
      break;
      case 2:
      $('.face.back').css('background-color', "GoldenRod");
      break;
      case 3:
      $('.face.back').css('background-color', "FireBrick");
      break;
      default:
      $('.face.back').css('background-color', "Coral");
      break;
    }
  }
  // Affiche les cartes
  var paire1 = {
    recto : $('.f1_container').appendTo('#scene'),
    verso : distributionVerso(chiffreAleatoire)
  };
  console.log(chiffreAleatoire);

  /////////////////////////////////// Carte 1   ///////////////////////////////////


  // var paire2 = {
  //   recto : $('.f1_container').clone().appendTo('#scene'),
  //   verso : distributionVerso(chiffreAleatoire)
  // };
  // console.log(chiffreAleatoire);

  // var paire3 = $('.f1_container').clone().appendTo('#scene');
  // var paire4 = $('.f1_container').clone().appendTo('#scene');



  //   window.onload = function () {
  //     // paireAleatoire(rectoAleatoire);
  //
  //
  //
  // };
  //


});
